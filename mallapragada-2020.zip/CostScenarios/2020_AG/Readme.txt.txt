Following conversation with David Keith on June 13

Scaled H2 storage costs based on 6/10th rule

Reflect on stack replacement cost- 7% of capital cost